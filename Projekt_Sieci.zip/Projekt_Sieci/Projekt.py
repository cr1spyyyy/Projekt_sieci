import whois
from datetime import datetime
import os
import re
import shutil

def read_domains_from_file(file_path):
    # Wczytywanie listy domen z pliku i walidacja nazw domen
    try:
        with open(file_path, 'r') as file:
            domains = [line.strip() for line in file.readlines() if line.strip()]
        valid_domains = [domain for domain in domains if validate_domain(domain)]
        if not valid_domains:
            print("Nie znaleziono poprawnych nazw domen w pliku.")
            exit()
        return valid_domains
    except FileNotFoundError:
        print(f"Nie znaleziono pliku: {file_path}")
        exit()


def validate_domain(domain):
    # Sprawdzenie, czy nazwa domeny jest poprawna (przy użyciu regex)
    domain_regex = re.compile(
        r"^(?:[a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,}$"
    )
    return bool(domain_regex.match(domain))


def get_domain_info(domain):
    # Pobieranie danych o domenie z bazy whois
    try:
        w = whois.whois(domain)

        owner = w.org if w.org else "Brak danych"
        creation_date = w.creation_date
        expiration_date = w.expiration_date

        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if isinstance(expiration_date, list):
            expiration_date = expiration_date[0]

        days_to_expire = (expiration_date - datetime.now()).days

        return {
            "domena": domain,
            "właściciel": owner,
            "data rejestracji": creation_date.strftime('%Y-%m-%d') if creation_date else "Brak danych",
            "data wygaśnięcia": expiration_date.strftime('%Y-%m-%d') if expiration_date else "Brak danych",
            "dni do wygaśnięcia": days_to_expire if expiration_date else "Brak danych"
        }
    except Exception as e:
        print(f"Błąd przy przetwarzaniu domeny {domain}: {e}")
        return {
            "domena": domain,
            "właściciel": "Błąd",
            "data rejestracji": "Błąd",
            "data wygaśnięcia": "Błąd",
            "dni do wygaśnięcia": "Błąd"
        }


def write_report_to_file(raport_path, domain_info_list):
    try:
        # Sprawdzenie dostępnego miejsca na dysku
        drive = os.path.splitdrive(raport_path)[0] or os.getcwd()
        total, used, free = shutil.disk_usage(drive)
        required_space = 1024 * 1024  # Przyjmujemy, że plik raportu zajmie około 1 MB
        if free < required_space:
            print("Brak wystarczającego miejsca na dysku, aby zapisać raport.")
            exit()

        with open(raport_path, 'w') as file:
            file.write(f"Raport domenowy na dzień {datetime.now()}\n")
            file.write("=" * 50 + "\n\n")
            for info in domain_info_list:
                file.write(f"Domena: {info['domena']}\n")
                file.write(f"Właściciel: {info['właściciel']}\n")
                file.write(f"Data rejestracji: {info['data rejestracji']}\n")
                file.write(f"Data wygaśnięcia: {info['data wygaśnięcia']}\n")
                file.write(f"Dni do wygaśnięcia: {info['dni do wygaśnięcia']}\n")
                file.write("-" * 50 + "\n")
    except IOError as e:
        print(f"Błąd podczas zapisywania pliku raportu: {e}")
        exit()


def main():
    input_file = "domeny.txt"  # Plik z listą domen
    output_file = "raport.txt"  # Plik zawierający raport

    # Sprawdzenie poprawności działania biblioteki whois
    try:
        whois.whois("example.com")
    except Exception as e:
        print(f"Błąd działania biblioteki whois: {e}")
        exit()

    domains = read_domains_from_file(input_file)
    if not domains:
        print("Nie podano żadnych domen do sprawdzenia.")
        return

    domain_info_list = [get_domain_info(domain) for domain in domains]
    write_report_to_file(output_file, domain_info_list)
    print(f"Raport został wykonany pomyślnie!")
    print(f"Zapisano go do pliku: {output_file}")


if __name__ == "__main__":
    main()
